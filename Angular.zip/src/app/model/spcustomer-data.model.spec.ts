import { SPCustomerData } from './spcustomer-data.model';

describe('SPCustomerData', () => {
  it('should create an instance', () => {
    expect(new SPCustomerData()).toBeTruthy();
  });
});
