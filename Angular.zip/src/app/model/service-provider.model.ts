export class ServiceProvider {
    
    public accountNumber : Number ;
 
    public addressProofUpload : File ;
 
    
    public bankName : string;
 
    
    public category : string;
 
    
    public companyAddress : string;
    
    
    public gstin : string ;   
    
    public mobileNumber : Number;
 
    public nameOfCompany : string;
 
    
    public panCardUpload : File;
    
    
    public panNumber : string;
 
    public password : string;
 
    public remarks : string;
 
    public requestDate : Date ;
 
    
    public spi : Number;
    
    
    public status : String;
 
    public userId : String;
 
}
