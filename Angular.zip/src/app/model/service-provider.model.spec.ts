import { ServiceProvider } from './service-provider.model';

describe('ServiceProvider', () => {
  it('should create an instance', () => {
    expect(new ServiceProvider()).toBeTruthy();
  });
});
