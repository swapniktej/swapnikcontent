export class SPCustomerData {
    bills:String;
    userId:String;
}
