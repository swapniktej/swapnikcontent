import { BankResponse } from './bank-response.model';

describe('BankResponse', () => {
  it('should create an instance', () => {
    expect(new BankResponse()).toBeTruthy();
  });
});
