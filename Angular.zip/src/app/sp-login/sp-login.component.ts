import { SPCustomerData } from './../model/spcustomer-data.model';
import { Component, OnInit } from '@angular/core';
import { SpService } from '../service/sp.service';
import { ServiceProvider } from '../model/service-provider.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sp-login',
  templateUrl: './sp-login.component.html',
  styleUrls: ['./sp-login.component.css']
})
export class SpLoginComponent implements OnInit {

  userId: string;
  serviceProvider: ServiceProvider;
  postlogin=false;
  errorMsg:String;
  approved=false;
  SPbills:File;
  successMessage:String;
  spdata:SPCustomerData;
  csv: string;

  constructor(private spService: SpService, private router: Router) {
    this.userId = "";
    this.serviceProvider = null;
    this.spdata=new SPCustomerData();
  }

  ngOnInit() {
  }
  upload(){
    this.spdata.userId=this.userId;
    this.spdata.bills=this.csv;
    console.log("here"+this.spdata);
    this.spService.upload(this.spdata).subscribe(
      (data)=> {
        this.successMessage=data.remarks;
        console.log("DONE")
      }
    )
  }

  public changeListener(files: FileList){
    console.log(files);
    if(files && files.length > 0) {
       let file : File = files.item(0); 
         console.log(file.name);
         console.log(file.size);
         console.log(file.type);
         let reader: FileReader = new FileReader();
         reader.readAsText(file);
         reader.onload = (e) => {
            this.csv = reader.result as string;
            console.log(this.csv);
         }
      }
  }

  login() {
    this.spService.getById(this.userId).subscribe(
      (data) => {
        this.serviceProvider = data;
        this.postlogin=true;
        if(this.serviceProvider.status=="Approved"){
          this.approved=true;
        }
        else{
          this.approved=false;
        }
      },
      (error) =>{
        this.errorMsg = error;
        alert(this.errorMsg);
      }
      
      
    );
  }

}