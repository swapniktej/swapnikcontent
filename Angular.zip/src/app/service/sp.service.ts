import { SPCustomerData } from './../model/spcustomer-data.model';
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, of, throwError } from 'rxjs';
import { ServiceProvider } from '../model/service-provider.model';
import { BankResponse } from '../model/bank-response.model';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SpService {

  bankSubmit=false;
  baseUrl:string;
  errorMsg:String;
  constructor(private http:HttpClient) {
    this.baseUrl=`${environment.baseMwUrl}`;
  }

  provider: ServiceProvider;
  
  upload(spdata:SPCustomerData):Observable<BankResponse>{
    return this.http.post<BankResponse>(`${this.baseUrl}/up`,spdata).pipe(catchError(this.errorHandler));
  }
  
  add(sp:ServiceProvider):Observable<ServiceProvider>{
    this.provider=sp;
    console.log("before sending: "+sp);
    return this.http.post<ServiceProvider>(`${this.baseUrl}/registeredDetails`,sp).pipe(catchError(this.errorHandler));
  }

  getById(userId:String):Observable<ServiceProvider>{
    console.log("getbyid"+userId);
    return this.http.get<ServiceProvider>(`${this.baseUrl}/loginDetails/${userId}`).pipe(catchError(this.errorHandler));
  }

  getPendingList():Observable<ServiceProvider[]>{
    return this.http.get<ServiceProvider[]>(`${this.baseUrl}/pendingList`).pipe(catchError(this.errorHandler));
  }

  getHistory():Observable<ServiceProvider[]>{
    return this.http.get<ServiceProvider[]>(`${this.baseUrl}/showHistory`).pipe(catchError(this.errorHandler));
  }


  getStatus(bankResponse :BankResponse):Observable<BankResponse>{
 
    return this.http.post<BankResponse>(`${this.baseUrl}/updateSP`,bankResponse).pipe(catchError(this.errorHandler));
  }
 
  
  getDetails(serviceProvider:ServiceProvider):Observable<ServiceProvider>{
 
    return this.http.post<ServiceProvider>(`${this.baseUrl}/registeredDetails`,serviceProvider).pipe(catchError(this.errorHandler));
  }
  errorHandler(error : HttpErrorResponse){
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      this.errorMsg=error.error;
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
     this.errorMsg);
  
  }

}