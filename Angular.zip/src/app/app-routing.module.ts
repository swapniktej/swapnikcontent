import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {DashboardComponent} from './dashboard/dashboard.component';



import {SpLoginComponent} from './sp-login/sp-login.component';
import {BankerComponent} from './banker/banker.component';


import { from } from 'rxjs';
import { NewRegistrationFormComponent } from './new-registration-form/new-registration-form.component';
import { PendingListComponent } from './pending-list/pending-list.component';
import { ShowHistoryComponent } from './show-history/show-history.component';
import { PendingDetailsComponent } from './pending-details/pending-details.component';
 

const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'spLogin',component:SpLoginComponent},
  {path:'banker',component:BankerComponent},
  {path:'newRegistrationForm',component:NewRegistrationFormComponent},
  {path:'pendingList',component:PendingListComponent},
  {path:'showHistory',component:ShowHistoryComponent},
  {path:'selected',component:PendingDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
