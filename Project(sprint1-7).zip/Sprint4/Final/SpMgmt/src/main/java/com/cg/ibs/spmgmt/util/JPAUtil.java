package com.cg.ibs.spmgmt.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.cg.ibs.spmgmt.bean.ServiceProvider;

public class JPAUtil {
	private static EntityManagerFactory entityManagerFactory;
	private static EntityManager entityManager;
	static {
		entityManagerFactory = Persistence.createEntityManagerFactory("persistentName");  
	}
	

	public static EntityManager getEntityManager() {

		if (null == entityManager || (!entityManager.isOpen())) {
			entityManager = entityManagerFactory.createEntityManager();
		}
		return entityManager;
	}

	public static EntityTransaction getTransaction() {
		return getEntityManager().getTransaction();
	}
}
