package com.cg.ibs.spmgmt.testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import javax.persistence.EntityManager;
import javax.transaction.Transaction;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import com.cg.ibs.spmgmt.bean.ServiceProvider;
import com.cg.ibs.spmgmt.dao.ServiceProviderDaoImpl;
import com.cg.ibs.spmgmt.exception.IBSException;
import com.cg.ibs.spmgmt.exception.RegisterException;
import com.cg.ibs.spmgmt.service.ServiceProviderServiceImpl;
import com.cg.ibs.spmgmt.util.JPAUtil;

import net.bytebuddy.implementation.bind.annotation.IgnoreForBinding;

class ServiceProviderServiceImplTest {

	ServiceProviderServiceImpl impl = null;
	ServiceProviderDaoImpl daoImpl = null;
	ServiceProvider provider;
	@BeforeEach
	void setUp() {
//		impl = new ServiceProviderServiceImpl();
//		daoImpl = new ServiceProviderDaoImpl();
	}

	@AfterEach
	void destr() {
		// TODO Auto-generated method stub
		impl = null;
		daoImpl = null;
	}

	@Test
	void test1GenerateIdPassword() {
		try {
			ServiceProvider serviceProvider = new ServiceProvider();
			serviceProvider.setNameOfCompany("Vodafone");
			assertEquals("Vodaf", impl.generateIdPassword(serviceProvider).getUserId());
			assertNotNull(impl.generateIdPassword(serviceProvider).getPassword());
		} catch (RegisterException e) {
			System.out.println(e.getMessage());
		} catch (IBSException e) {
			System.out.println(e.getMessage());

		}
	}


	@Test
	void test1StoreSPDetails() {
		assertThrows(IBSException.class, () -> {
			impl.storeSPDetails(null);
		});
	}

	@Test
	void test1ValidateLogin() {
		try {
			assertEquals(true, impl.validateLogin("Relia", "T5cQV+pf"));
		} catch (IBSException e) {

			System.out.println(e.getMessage());
		}
	}

	@Test
	void test2ValidateLogin() {

		assertThrows(IBSException.class, () -> {
			impl.validateLogin("Relia", "87654321");
		});
	}
	

	@Test
	void test3ValidateLogin()  {
		assertThrows(IBSException.class, () -> {
			impl.validateLogin("Reliance", "12345678");
		});
	}

	@Test
	void test4ValidateLogin() {
		assertThrows(IBSException.class, () -> {
			impl.validateLogin("Reliance", "T5cQV+pf");
		});
	}

	@Test
	@Disabled
	void test1GetServiceProvider() {

		try {
			assertNotNull( impl.getServiceProvider("Vodaf"));
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	void test1ShowPending() {

		try {
			assertNotNull(impl.showPending());
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	@Disabled
	void testApproveSP() {
		try {
			impl.approveSP(impl.getServiceProvider("Relia"), true);
			assertTrue(impl.getServiceProvider("Relia").getStatus().equals("Approved"));
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	@Disabled
	void test2ApproveSP() {
		try {
			impl.approveSP(impl.getServiceProvider("Airte"), false);
			assertFalse(impl.getServiceProvider("Airte").getStatus().equals("Approved"));
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	void test1ValidateAdminLogin() {
		try {
			assertEquals(true, impl.validateAdminLogin("bank1", "pass1"));
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	void test2ValidateAdminLogin() {

		assertThrows(IBSException.class, () -> {
			impl.validateLogin("id1", "passed1");
		});
	}

	@Test
	void test3ValidateAdminLogin() {

		assertThrows(IBSException.class, () -> {
			impl.validateLogin("id4", "pass1");
		});
	}

	@Test
	void testShowHistory() {
		try {
			impl.showHistory();
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
		assertTrue(true);
	}

}
