package com.cg.ibs.spmgmt.bean;

import java.io.Serializable;
import java.util.Arrays;

public class BillsFile implements Serializable{
	private String bills;
	
	private String userId;

	public String getBills() {
		return bills;
	}

	public void setBills(String bills) {
		this.bills = bills;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "BillsFile [bills=" + bills + ", userId=" + userId + "]";
	}




}
